//package com.srs.entity;
//
//import java.util.Date;
//
//import jakarta.persistence.Basic;
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.SequenceGenerator;
//
//@Entity(name = "STUDENTS")
//public class StudentsEntity {
//	
//	
//	/*
//	 * @Id
//	 * 
//	 * @Column(name = "B#") private String id;
//	 * 
//	 * @Column(name = "FIRST_NAME") private String firstName;
//	 * 
//	 * @Column(name = "LAST_NAME") private String lastName;
//	 * 
//	 * @Column(name = "ST_LEVEL") private String stLevel;
//	 * 
//	 * @Column(name = "GPA") private String gpa;
//	 * 
//	 * @Column(name = "EMAIL") private String email;
//	 * 
//	 * @Column(name = "BDATE") private Date bDate;
//	 * 
//	 * public String getId() { return id; }
//	 * 
//	 * public void setId(String id) { this.id = id; }
//	 * 
//	 * public String getFirstName() { return firstName; }
//	 * 
//	 * public void setFirstName(String firstName) { this.firstName = firstName; }
//	 * 
//	 * public String getLastName() { return lastName; }
//	 * 
//	 * public void setLastName(String lastName) { this.lastName = lastName; }
//	 * 
//	 * public String getStLevel() { return stLevel; }
//	 * 
//	 * public void setStLevel(String stLevel) { this.stLevel = stLevel; }
//	 * 
//	 * public String getGpa() { return gpa; }
//	 * 
//	 * public void setGpa(String gpa) { this.gpa = gpa; }
//	 * 
//	 * public String getEmail() { return email; }
//	 * 
//	 * public void setEmail(String email) { this.email = email; }
//	 * 
//	 * public Date getbDate() { return bDate; }
//	 * 
//	 * public void setbDate(Date bDate) { this.bDate = bDate; }
//	 * 
//	 * 
//	 * 
//	 * 
//	 * 
//	 * 
//	 * 
//	 */
//	
//	
//	
//	
//
//}
