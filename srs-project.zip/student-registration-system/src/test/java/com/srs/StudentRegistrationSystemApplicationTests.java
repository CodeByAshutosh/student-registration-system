package com.srs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRegistrationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
